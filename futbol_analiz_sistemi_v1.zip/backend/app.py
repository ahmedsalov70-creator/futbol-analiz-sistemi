import os, math
from datetime import datetime, timezone
from typing import Optional
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()
app = FastAPI(title="Futbol Analiz Motoru", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

FOOTBALL_KEY = os.getenv("FOOTBALL_API_KEY", "")
FOOTBALL_BASE = os.getenv("FOOTBALL_API_BASE_URL", "https://v3.football.api-sports.io")
WEATHER_BASE = os.getenv("WEATHER_BASE_URL", "https://api.open-meteo.com/v1/forecast")

class AnalyzeRequest(BaseModel):
    home_team: str
    away_team: str
    match_datetime: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

def poisson_pmf(k, lam):
    if lam <= 0: return 1.0 if k == 0 else 0.0
    return math.exp(-lam) * (lam ** k) / math.factorial(k)

def score_matrix(lh, la, max_goals=8):
    m = {}
    for h in range(max_goals + 1):
        for a in range(max_goals + 1):
            m[(h,a)] = poisson_pmf(h, lh) * poisson_pmf(a, la)
    total = sum(m.values())
    return {k:v/total for k,v in m.items()}

def probabilities(lh, la):
    m = score_matrix(lh, la)
    home = sum(p for (h,a),p in m.items() if h>a)
    draw = sum(p for (h,a),p in m.items() if h==a)
    away = sum(p for (h,a),p in m.items() if h<a)
    over25 = sum(p for (h,a),p in m.items() if h+a >= 3)
    btts = sum(p for (h,a),p in m.items() if h>0 and a>0)
    top = sorted(m.items(), key=lambda x:x[1], reverse=True)[:5]
    return {
        "home_win": round(home*100,2),
        "draw": round(draw*100,2),
        "away_win": round(away*100,2),
        "over_2_5": round(over25*100,2),
        "under_2_5": round((1-over25)*100,2),
        "btts_yes": round(btts*100,2),
        "btts_no": round((1-btts)*100,2),
        "top_scores": [{"score": f"{h}-{a}", "probability": round(p*100,2)} for (h,a),p in top]
    }

async def football_get(path, params=None):
    if not FOOTBALL_KEY:
        return None, "FOOTBALL_API_KEY_missing"
    headers = {"x-apisports-key": FOOTBALL_KEY}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(f"{FOOTBALL_BASE}{path}", headers=headers, params=params or {})
        r.raise_for_status()
        return r.json(), None

async def weather(lat, lon):
    if lat is None or lon is None:
        return None
    params = {
        "latitude": lat, "longitude": lon,
        "hourly": "temperature_2m,relative_humidity_2m,precipitation_probability,precipitation,wind_speed_10m,wind_gusts_10m,visibility",
        "forecast_days": 2, "timezone": "auto"
    }
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(WEATHER_BASE, params=params)
        r.raise_for_status()
        return r.json()

@app.get("/health")
async def health():
    return {"ok": True, "football_provider_configured": bool(FOOTBALL_KEY)}

@app.post("/api/analyze")
async def analyze(req: AnalyzeRequest):
    # Provider adapter is intentionally isolated. Team/match resolution will be added
    # after receiving a real provider key, preventing fabricated football statistics.
    weather_data = None
    if req.latitude is not None and req.longitude is not None:
        try:
            weather_data = await weather(req.latitude, req.longitude)
        except Exception as e:
            weather_data = {"error": str(e)}

    if not FOOTBALL_KEY:
        return {
            "status": "needs_api_key",
            "message": "Gerçek futbol verisini çekmek için backend .env içine FOOTBALL_API_KEY eklenmeli.",
            "mathematical_engine": "ready",
            "weather_available": weather_data is not None,
            "data_policy": "Eksik futbol verisi için tahmini/sahte veri üretilmiyor."
        }

    # Resolve teams
    home_data, err1 = await football_get("/teams", {"search": req.home_team})
    away_data, err2 = await football_get("/teams", {"search": req.away_team})
    if err1 or err2:
        raise HTTPException(502, detail={"home": err1, "away": err2})

    if not home_data.get("response") or not away_data.get("response"):
        raise HTTPException(404, detail="Takım bulunamadı.")

    home = home_data["response"][0]["team"]
    away = away_data["response"][0]["team"]

    # This endpoint intentionally does not fabricate lambdas.
    # Next integration step: fetch recent fixtures/statistics and estimate
    # opponent-adjusted attack/defence ratings from actual observations.
    return {
        "status": "provider_connected",
        "home_team": {"id": home["id"], "name": home["name"]},
        "away_team": {"id": away["id"], "name": away["name"]},
        "weather": weather_data,
        "next_step": "fixtures_statistics_injuries_lineups -> calibrated model"
    }
