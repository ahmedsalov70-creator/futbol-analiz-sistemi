# Futbol Analiz Sistemi v1

Gerçek futbol verilerini matematiksel modele dönüştürmek için başlangıç sürümü.

## Mimari
Android telefon -> Web/PWA arayüzü -> FastAPI backend -> Veri sağlayıcıları -> Matematik motoru

## Kurulum
1. Python 3.11+ kur.
2. `cd backend`
3. `pip install -r requirements.txt`
4. `.env.example` dosyasını `.env` olarak kopyala ve API anahtarını ekle.
5. `uvicorn app:app --reload`
6. Telefonda aynı ağdaki bilgisayarın IP adresinden frontend'i aç.

## Önemli
API anahtarı frontend'e konulmaz. Backend üzerinden kullanılır.
Eksik veri olduğunda sistem sayı uydurmaz; ilgili alanı `veri_yok` olarak işaretler.

## Model
- Rakip gücü düzeltilmiş form
- Hücum/savunma ratingleri
- Ev sahibi etkisi
- Recency weighting
- Poisson skor matrisi
- Düşük skorlar için Dixon-Coles düzeltmesi için genişletilebilir yapı
- 1-X-2 ve gol pazarları
- Veri tazeliği ve güven skoru

Bu sürüm üretim öncesi çekirdektir. Canlı futbol sağlayıcısı anahtarı bağlandığında gerçek maç verisi üzerinden çalışır.
